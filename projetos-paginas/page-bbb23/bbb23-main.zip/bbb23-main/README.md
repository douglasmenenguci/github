# PROJETO WEB COMPLETO BBB23
## HTML, CSS e JS

Salve Devs,

Este é um projeto web completo de html, css e js sobre o tema BBB23.

![BBB23](https://i.ibb.co/BPyMWhB/bbb23a.png)

Vamos fazer passo a passo a construção da aplicação.
E, ir acrescentando novas funcionalidades ao longo de cada aula.

### Link da fonte usada no projeto
~~~html
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Bebas+Neue&display=swap" rel="stylesheet">
~~~

### Códigos html usados para gerar símbolos
~~~html
&copy;
&uparrow;
~~~

