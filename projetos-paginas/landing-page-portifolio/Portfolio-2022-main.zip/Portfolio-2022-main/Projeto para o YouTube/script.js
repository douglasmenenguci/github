
var typed = new typed("span",{
    strings:["Elizabeth Elmiz.","web Developer.","UX Designer.","Photographer."],
    typeSpeed: 70,
    backSpeed: 60,
    loop: true
});
