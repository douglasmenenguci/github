# LandingPage

Nesse projeto iremos desenvolver uma landing page do zero.
.
.
.
Dicas:
1- Salva as imagens dentro da pasta do projeto com o nome "img".
2- Assista o vídeo no YouTube completo 🚀
3- Coloque a mão no código 🚀
.
.
.
